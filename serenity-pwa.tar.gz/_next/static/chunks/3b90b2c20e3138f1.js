__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/f58ef855301eabaa.js",
  "static/chunks/turbopack-36ce72f00bfdd00c.js"
])
